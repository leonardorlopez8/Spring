package edu.curso.spring1.primerospasos1.bo;

public class Proveedor {

}
