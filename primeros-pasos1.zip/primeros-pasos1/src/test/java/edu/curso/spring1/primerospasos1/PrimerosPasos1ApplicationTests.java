package edu.curso.spring1.primerospasos1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerosPasos1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
